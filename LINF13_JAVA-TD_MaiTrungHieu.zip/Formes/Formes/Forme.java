import java.awt.*;
//import javax.swing.*;

public interface Forme
{
	public void redessiner( Graphics g );
	public void setCouleur(Color c);
}
